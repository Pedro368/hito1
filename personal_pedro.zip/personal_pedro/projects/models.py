from django.db import models

# Create your models here.
class Project(models.Model):
    titulo = models.CharField(max_length=100)
    descripcion = models.TextField()
    autor = models.CharField(max_length=40)
    imagen = models.FilePathField(path="/img")
    precio = models.FloatField()